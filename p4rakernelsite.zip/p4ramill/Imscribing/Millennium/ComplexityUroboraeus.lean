import Imscribing.Millennium.Uroboraeus
import Imscribing.Millennium.TrineOperatorAlgebra

namespace Imscribing.Millennium.ComplexityUroboraeus

open Imscribing.Paraconsistent.Uroboraeus
open Imscribing.Millennium.TrineOperatorAlgebra

/-! ## Part 1: Resource-Bounded Frobenius Section (P = NP Characterization) -/

structure SearchProblem (I W : Type*) where
  verify     : I → W → Bool
  isPolyCost : (I → Option W) → Prop

def InNP {I W : Type*} (P : SearchProblem I W) (x : I) : Prop :=
  ∃ w : W, P.verify x w = true

/-- Resource-bounded Frobenius closure: a polynomial-time folding map μ
    inverting polynomial-time verification δ on all valid instances. -/
def HasPolySection {I W : Type*} (P : SearchProblem I W) : Prop :=
  ∃ μ : I → Option W, P.isPolyCost μ ∧
    ∀ x : I, InNP P x → ∃ w : W, μ x = some w ∧ P.verify x w = true

theorem p_eq_np_iff_poly_section {I W : Type*} (P : SearchProblem I W) :
    (∃ μ : I → Option W, P.isPolyCost μ ∧
      ∀ x : I, (∃ w : W, P.verify x w = true) →
        ∃ w : W, μ x = some w ∧ P.verify x w = true) ↔
    HasPolySection P := by
  rfl

/-- Explicit Frobenius verification projection δ(x, w) = (x, verify x w). -/
def VerifyFiber {I W : Type*} (P : SearchProblem I W) (x : I) (w : W) : I × Bool :=
  (x, P.verify x w)

def IsResourceBoundedFrobeniusSection {I W : Type*}
    (P : SearchProblem I W) (μ : I → Option W) : Prop :=
  P.isPolyCost μ ∧
  ∀ x : I, InNP P x → ∃ w : W, μ x = some w ∧ VerifyFiber P x w = (x, true)

theorem hasPolySection_iff_frobenius {I W : Type*} (P : SearchProblem I W) :
    HasPolySection P ↔ ∃ μ, IsResourceBoundedFrobeniusSection P μ := by
  simp [HasPolySection, IsResourceBoundedFrobeniusSection, VerifyFiber]

/-! ## Part 2: Boolean Collapse (t ↦ T, f ↦ F) Destroys the (2,2,2) Doublet -/

def decodeFin16 (x : Fin 16) : Sixteen3 :=
  (if bitT x == 1 then {.T} else ∅) ∪
  (if bitF x == 1 then {.F} else ∅) ∪
  (if bitt x == 1 then {.t} else ∅) ∪
  (if bitf x == 1 then {.f} else ∅)

def collapseAtom : EpistemicAtom → EpistemicAtom
  | .T => .T
  | .F => .F
  | .t => .T
  | .f => .F

def collapseSixteen3 (x : Sixteen3) : Sixteen3 :=
  x.image collapseAtom

/-- Before Boolean collapse, |0110⟩ = {F, t} and |1001⟩ = {T, f} are distinct
    states sharing the unique degenerate rank triple (2,2,2). -/
theorem doublet_distinct_at_222 :
    decodeFin16 6 ≠ decodeFin16 9 ∧
    rankTriple 6 = (2, 2, 2) ∧
    rankTriple 9 = (2, 2, 2) := by
  decide

/-- Identifying non-constructive NP acceptability (t) with constructive proof (T)
    and coNP (f) with (F) collapses BOTH doublet states onto the Boolean explosion {T, F}. -/
theorem boolean_collapse_destroys_doublet :
    collapseSixteen3 (decodeFin16 6) = GlutState ∧
    collapseSixteen3 (decodeFin16 9) = GlutState := by
  decide

/-! ## Part 3: Hadamard Chirality Splits the Unique (2,2,2) Doublet -/

private def sgnT (x : Fin 16) : ℤ := if bitT x == 1 then 1 else -1
private def sgnF (x : Fin 16) : ℤ := if bitF x == 1 then 1 else -1
private def sgnt (x : Fin 16) : ℤ := if bitt x == 1 then 1 else -1
private def sgnf (x : Fin 16) : ℤ := if bitf x == 1 then 1 else -1

def uInfo (x : Fin 16) : ℤ :=
  sgnT x + sgnF x + sgnt x + sgnf x

def uTruth (x : Fin 16) : ℤ :=
  sgnT x - sgnF x + sgnt x - sgnf x

def uConstr (x : Fin 16) : ℤ :=
  sgnT x + sgnF x - sgnt x - sgnf x

/-- Fourth Hadamard coordinate u_χ = ε_T - ε_F - ε_t + ε_f on Fin 16. -/
def uChi (x : Fin 16) : ℤ :=
  sgnT x - sgnF x - sgnt x + sgnf x

/-- Parity-closure bit n_5 = n_T ⊕ n_F ⊕ n_t ⊕ n_f for the Spin(10) spinor lift. -/
def parityBit5 (x : Fin 16) : ℕ :=
  ((if bitT x == 1 then 1 else 0) +
   (if bitF x == 1 then 1 else 0) +
   (if bitt x == 1 then 1 else 0) +
   (if bitf x == 1 then 1 else 0)) % 2

/-- Uniqueness of the (2,2,2) degeneracy: rankTriple separates all other pairs in Fin 16. -/
theorem rankTriple_injective_off_doublet :
    ∀ x y : Fin 16, x ≠ y → rankTriple x = rankTriple y →
      (x = 6 ∧ y = 9) ∨ (x = 9 ∧ y = 6) := by
  decide

/-- The omitted Hadamard coordinate u_χ separates the (2,2,2) doublet maximally. -/
theorem chirality_splits_222_doublet :
    uChi 6 = -4 ∧ uChi 9 = 4 := by
  decide

/-- Adjoining u_χ makes the 4D Hadamard/filtration map globally injective on Fin 16. -/
theorem hadamard_4d_injective :
    ∀ x y : Fin 16, rankTriple x = rankTriple y → uChi x = uChi y → x = y := by
  decide

/-- Exact Hadamard sphere and T-spine identities across all 16 states. -/
theorem hadamard_sphere_and_spine :
    ∀ x : Fin 16,
      (uInfo x)^2 + (uTruth x)^2 + (uConstr x)^2 + (uChi x)^2 = 16 ∧
      uInfo x + uTruth x + uConstr x + uChi x = 4 * sgnT x := by
  decide

/-- Both (2,2,2) doublet states have closure bit n_5 = 0, placing them in S^+_10 (Λ^2 V). -/
theorem doublet_in_even_spinor_sector :
    parityBit5 6 = 0 ∧ parityBit5 9 = 0 := by
  decide

/-- States 5 ({F, f}) and 10 ({T, t}) lie on the zero-chirality diagonal, whereas state 6 has u_χ = -4. -/
theorem diagonal_has_zero_chirality :
    uChi 5 = 0 ∧ uChi 10 = 0 ∧ uChi 6 = -4 := by
  decide

/-! ## Part 4: Non-Invertibility of the Graded Exceptional Operator on P222 -/

/-- The induced graded Jordan block P222 * Ω_{(0,0,0)} * P222 admits no right-inverse
    within the 2D graded sector gr_{(2,2,2)}(V). -/
theorem no_right_inverse_on_doublet :
    ∀ inv : Matrix (Fin 16) (Fin 16) ℤ,
      (P222 * omegaRaw27 * P222) * inv ≠ P222 := by
  intro inv h
  have h66 : ((P222 * omegaRaw27 * P222) * inv) 6 6 = P222 6 6 :=
    congrArg (fun M : Matrix (Fin 16) (Fin 16) ℤ => M 6 6) h
  rw [Matrix.mul_apply] at h66
  have hblk := omega_graded_jordan_block
  have hzero : ∀ k : Fin 16, (P222 * omegaRaw27 * P222) 6 k * inv k 6 = 0 := by
    intro k
    rw [p222_sandwich]
    by_cases hk : k = 6 ∨ k = 9
    · rcases hk with rfl | rfl
      · simp [hblk.2.1]
      · simp [hblk.2.2.1]
    · simp [hk]
  simp only [hzero, Finset.sum_const_zero] at h66
  have hp66 : P222 6 6 = 1 := by decide
  rw [hp66] at h66
  exact absurd h66 (by decide)

/-- Scalar extension to any nontrivial ring R does not restore right-invertibility on P222. -/
theorem no_right_inverse_on_doublet_ring {R : Type*} [Ring R] [Nontrivial R] :
    ∀ inv : Matrix (Fin 16) (Fin 16) R,
      (P222.map (Int.castRingHom R) *
       omegaRaw27.map (Int.castRingHom R) *
       P222.map (Int.castRingHom R)) * inv ≠
      P222.map (Int.castRingHom R) := by
  intro inv h
  have h66 :
      ((P222.map (Int.castRingHom R) *
        omegaRaw27.map (Int.castRingHom R) *
        P222.map (Int.castRingHom R)) * inv) 6 6 =
      (P222.map (Int.castRingHom R)) 6 6 :=
    congrArg (fun M : Matrix (Fin 16) (Fin 16) R => M 6 6) h
  rw [Matrix.mul_apply] at h66
  have hblk := omega_graded_jordan_block
  have hzero : ∀ k : Fin 16,
      (P222.map (Int.castRingHom R) *
       omegaRaw27.map (Int.castRingHom R) *
       P222.map (Int.castRingHom R)) 6 k * inv k 6 = 0 := by
    intro k
    have hs : (P222 * omegaRaw27 * P222) 6 k = 0 := by
      rw [p222_sandwich]
      by_cases hk : k = 6 ∨ k = 9
      · rcases hk with rfl | rfl
        · simp [hblk.2.1]
        · simp [hblk.2.2.1]
      · simp [hk]
    have hmap :
        (P222.map (Int.castRingHom R) *
         omegaRaw27.map (Int.castRingHom R) *
         P222.map (Int.castRingHom R)) 6 k =
        (Int.castRingHom R) ((P222 * omegaRaw27 * P222) 6 k) := by
      simp only [Matrix.mul_apply, Matrix.map_apply, map_sum, map_mul]
    rw [hmap, hs, map_zero, zero_mul]
  simp only [hzero, Finset.sum_const_zero] at h66
  have hp66 : P222 6 6 = 1 := by decide
  simp [hp66] at h66

/-- Left-invertibility obstruction on P222 given vanishing column 6 in the graded block. -/
theorem no_left_inverse_on_doublet
    (hcol6 : (P222 * omegaRaw27 * P222) 6 6 = 0 ∧ (P222 * omegaRaw27 * P222) 9 6 = 0) :
    ∀ inv : Matrix (Fin 16) (Fin 16) ℤ,
      inv * (P222 * omegaRaw27 * P222) ≠ P222 := by
  intro inv h
  have h66 : (inv * (P222 * omegaRaw27 * P222)) 6 6 = P222 6 6 :=
    congrArg (fun M : Matrix (Fin 16) (Fin 16) ℤ => M 6 6) h
  rw [Matrix.mul_apply] at h66
  have hzero : ∀ k : Fin 16, inv 6 k * (P222 * omegaRaw27 * P222) k 6 = 0 := by
    intro k
    by_cases hk : k = 6 ∨ k = 9
    · rcases hk with rfl | rfl
      · simp [hcol6.1]
      · simp [hcol6.2]
    · rw [p222_sandwich]
      simp [hk]
  simp only [hzero, Finset.sum_const_zero] at h66
  have hp66 : P222 6 6 = 1 := by decide
  rw [hp66] at h66
  exact absurd h66 (by decide)

/-! ## Part 5: Epistemic Bridge Between HasPolySection and the (2,2,2) Doublet -/

private lemma six_eq : ({.F} : Sixteen3) ∪ {.t} = decodeFin16 6 := by decide
private lemma ten_eq : ({.T} : Sixteen3) ∪ {.t} = decodeFin16 10 := by decide
private lemma five_eq : ({.F} : Sixteen3) ∪ {.f} = decodeFin16 5 := by decide

section ComplexityBridge

open Classical

/-- Epistemic profile of a candidate solver μ on instance x of search problem P. -/
noncomputable def epistemicProfile {I W : Type*}
    (P : SearchProblem I W) (μ : I → Option W) (x : I) : Sixteen3 :=
  (if ∃ w : W, μ x = some w ∧ P.verify x w = true then ({.T} : Sixteen3) else {.F}) ∪
  (if InNP P x then ({.t} : Sixteen3) else {.f})

lemma mem_epistemicProfile_T {I W : Type*}
    (P : SearchProblem I W) (μ : I → Option W) (x : I) :
    EpistemicAtom.T ∈ epistemicProfile P μ x ↔
      ∃ w : W, μ x = some w ∧ P.verify x w = true := by
  unfold epistemicProfile
  by_cases h1 : ∃ w : W, μ x = some w ∧ P.verify x w = true <;>
  by_cases h2 : InNP P x <;>
  simp [h1, h2]

lemma mem_epistemicProfile_F {I W : Type*}
    (P : SearchProblem I W) (μ : I → Option W) (x : I) :
    EpistemicAtom.F ∈ epistemicProfile P μ x ↔
      ¬ (∃ w : W, μ x = some w ∧ P.verify x w = true) := by
  unfold epistemicProfile
  by_cases h1 : ∃ w : W, μ x = some w ∧ P.verify x w = true <;>
  by_cases h2 : InNP P x <;>
  simp [h1, h2]

lemma mem_epistemicProfile_t {I W : Type*}
    (P : SearchProblem I W) (μ : I → Option W) (x : I) :
    EpistemicAtom.t ∈ epistemicProfile P μ x ↔ InNP P x := by
  unfold epistemicProfile
  by_cases h1 : ∃ w : W, μ x = some w ∧ P.verify x w = true <;>
  by_cases h2 : InNP P x <;>
  simp [h1, h2]

lemma mem_epistemicProfile_f {I W : Type*}
    (P : SearchProblem I W) (μ : I → Option W) (x : I) :
    EpistemicAtom.f ∈ epistemicProfile P μ x ↔ ¬ InNP P x := by
  unfold epistemicProfile
  by_cases h1 : ∃ w : W, μ x = some w ∧ P.verify x w = true <;>
  by_cases h2 : InNP P x <;>
  simp [h1, h2]

/-- A search problem admits a polynomial-time Frobenius section iff a poly-time μ
    keeps every instance off the (2,2,2) obstruction state decodeFin16 6 = {F, t}. -/
theorem hasPolySection_iff_avoids_doublet_6 {I W : Type*} (P : SearchProblem I W) :
    HasPolySection P ↔
      ∃ μ : I → Option W, P.isPolyCost μ ∧
        ∀ x : I, epistemicProfile P μ x ≠ decodeFin16 6 := by
  constructor
  · rintro ⟨μ, hpoly, hcomp⟩
    refine ⟨μ, hpoly, fun x heq => ?_⟩
    have ht : EpistemicAtom.t ∈ decodeFin16 6 := by decide
    rw [← heq, mem_epistemicProfile_t] at ht
    obtain ⟨w, hw, hv⟩ := hcomp x ht
    have hT : EpistemicAtom.T ∈ epistemicProfile P μ x :=
      (mem_epistemicProfile_T P μ x).2 ⟨w, hw, hv⟩
    rw [heq] at hT
    exact absurd hT (by decide)
  · rintro ⟨μ, hpoly, havoid⟩
    refine ⟨μ, hpoly, fun x hx => ?_⟩
    by_contra hno
    apply havoid x
    unfold epistemicProfile
    rw [if_neg hno, if_pos hx]
    exact six_eq

/-- Equivalently, HasPolySection P holds iff a poly-time μ maps all instances strictly
    onto the zero-chirality diagonal {decodeFin16 5, decodeFin16 10}. -/
theorem hasPolySection_iff_zero_chirality_diagonal {I W : Type*} (P : SearchProblem I W) :
    HasPolySection P ↔
      ∃ μ : I → Option W, P.isPolyCost μ ∧
        ∀ x : I, epistemicProfile P μ x = decodeFin16 10 ∨
                 epistemicProfile P μ x = decodeFin16 5 := by
  rw [hasPolySection_iff_avoids_doublet_6]
  constructor
  · rintro ⟨μ, hpoly, havoid⟩
    refine ⟨μ, hpoly, fun x => ?_⟩
    by_cases h1 : ∃ w : W, μ x = some w ∧ P.verify x w = true
    · left
      have hx : InNP P x := ⟨h1.choose, h1.choose_spec.2⟩
      unfold epistemicProfile
      rw [if_pos h1, if_pos hx]
      exact ten_eq
    · by_cases hx : InNP P x
      · exfalso
        apply havoid x
        unfold epistemicProfile
        rw [if_neg h1, if_pos hx]
        exact six_eq
      · right
        unfold epistemicProfile
        rw [if_neg h1, if_neg hx]
        exact five_eq
  · rintro ⟨μ, hpoly, hdiag⟩
    refine ⟨μ, hpoly, fun x heq => ?_⟩
    rcases hdiag x with h10 | h5
    · rw [h10] at heq; exact absurd heq (by decide)
    · rw [h5] at heq; exact absurd heq (by decide)

end ComplexityBridge

end Imscribing.Millennium.ComplexityUroboraeus